export type ProtecXErrorCode =
    | "NETWORK_ERROR"
    | "AUTHENTICATION_ERROR"
    | "VALIDATION_ERROR"
    | "API_ERROR"
    | "UNKNOWN_ERROR";

export class ProtecXError extends Error {
    public readonly code: string;
    public readonly status?: number;
    public readonly details?: any;

    constructor(message: string, code: ProtecXErrorCode | string, status?: number, details?: any) {
        super(message);
        this.name = "ProtecXError";
        this.code = code;
        this.status = status;
        this.details = details;

        // Fix prototype chain for custom errors in TypeScript
        Object.setPrototypeOf(this, ProtecXError.prototype);
    }

    static fromResponse(message: string, status: number, data?: any): ProtecXError {
        let errorCode: string = "API_ERROR";
        let errorMessage: string = message;

        if (data) {
            // Common backend error patterns
            errorCode = data.code || data.error?.code || data.errorCode || "API_ERROR";
            errorMessage = data.message || data.error?.message || data.errorMessage || message;
        }

        // Ensure we don't expose sensitive raw stack traces or internal details
        if (typeof errorMessage !== "string") {
            errorMessage = "Internal Server Error";
        }

        return new ProtecXError(errorMessage, errorCode, status, data);
    }

    static networkError(originalError: Error): ProtecXError {
        return new ProtecXError(
            originalError.message || "Network request failed",
            "NETWORK_ERROR"
        );
    }
}
