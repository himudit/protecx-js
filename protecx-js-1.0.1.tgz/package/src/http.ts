import { ProtecXError } from "./errors";
import { ProtecXConfig } from "./types";
import { TokenManager } from "./token-manager";

export class HttpClient {
    private config: ProtecXConfig;
    private tokenManager: TokenManager;

    constructor(config: ProtecXConfig, tokenManager: TokenManager) {
        this.config = config;
        this.tokenManager = tokenManager;
    }

    async request<T>(path: string, options: RequestInit = {}): Promise<T> {
        const url = `${this.config.baseUrl.replace(/\/$/, "")}${path}`;

        const headers = new Headers(options.headers);
        headers.set("Content-Type", "application/json");
        headers.set("x-project-id", this.config.projectId);
        headers.set("x-api-key", this.config.apiKey);

        const accessToken = this.tokenManager.getAccessToken();
        if (accessToken) {
            headers.set("Authorization", `Bearer ${accessToken}`);
        }

        try {
            const response = await fetch(url, {
                ...options,
                headers,
            });

            let data: any;
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.includes("application/json")) {
                data = await response.json();
            } else {
                data = await response.text();
            }

            if (!response.ok) {
                throw ProtecXError.fromResponse(
                    response.statusText || "Request failed",
                    response.status,
                    data
                );
            }

            return data as T;
        } catch (error) {
            if (error instanceof ProtecXError) {
                throw error;
            }
            throw ProtecXError.networkError(error as Error);
        }
    }

    get<T>(path: string, options?: RequestInit): Promise<T> {
        return this.request<T>(path, { ...options, method: "GET" });
    }

    post<T>(path: string, body?: any, options?: RequestInit): Promise<T> {
        return this.request<T>(path, {
            ...options,
            method: "POST",
            body: body ? JSON.stringify(body) : undefined,
        });
    }
}
