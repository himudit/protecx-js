import { HttpClient } from "./http";
import { Auth } from "./auth";
import { TokenManager } from "./token-manager";
import { ProtecXConfig } from "./types";

export * from "./types";
export * from "./errors";
export { TokenManager } from "./token-manager";

export class ProtecX {
    public auth: Auth;
    private http: HttpClient;
    private tokenManager: TokenManager;

    constructor(config: ProtecXConfig) {
        this.tokenManager = new TokenManager(config.persistTokens);
        this.http = new HttpClient(config, this.tokenManager);
        this.auth = new Auth(this.http, this.tokenManager);
    }
}

/**
 * Example Usage:
 * 
 * const protecx = new ProtecX({
 *   baseUrl: "https://protecx.onrender.com/api/v1",
 *   projectId: "proj_123",
 *   apiKey: "pk_live_xxx"
 * });
 * 
 * async function run() {
 *   try {
 *     const session = await protecx.auth.login({
 *       email: "user@example.com",
 *       password: "password123"
 *     });
 *     console.log("Logged in:", session.user);
 *   } catch (error) {
 *     if (error instanceof ProtecXError) {
 *       console.error(`Error ${error.code}: ${error.message} (${error.status})`);
 *     }
 *   }
 * }
 */
